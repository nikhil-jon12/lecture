

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class saveServlet
 */
@WebServlet("/saveServlet") 
public class saveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public saveServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	
		 response.setContentType("text/html");
		 PrintWriter out=response.getWriter();
		 
		 String name=request.getParameter("txtName");
		 String password=request.getParameter("txtPass");
		 String email=request.getParameter("txtEmail");
		 String country=request.getParameter("country");
		 
		 Employee e=new Employee();
		 
		 e.setName(name);
		 e.setPassword(password);
		 e.setEmail(email);
		 e.setCountry(country);
		 
		 int status=EmpDao.save(e);
		 if(status > 0)
		 {
			 out.print("Record Inserted Succesfully!!");
			 request.getRequestDispatcher("index.html").include(request, response);
		 }
		 else
		 {
			 out.print("Sorry!! Unable To Connect");
		 }
		 out.close();
	}

}
